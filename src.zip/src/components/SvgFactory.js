import React, { useState } from 'react';
import { ethers } from 'ethers';
import factoryAbi from './abi/factory.json';
import styles from './css/SvgFactory.module.css';

// ファクトリー・コントラクトのABIとアドレスを設定します。
// ABIはコントラクトのコンパイル時に生成されたものを使用してください。
const factoryAddress = '0xAdDcB528dD46ACB2A52412782AcD29014034629c'; // ファクトリー・コントラクトのアドレスをここに置きます。

const SvgFactory = () => {
  const [name, setName] = useState('');
  const [symbol, setSymbol] = useState('');
  const [contractAddress, setContractAddress] = useState('');

  const createNFTContract = async () => {
    try {
      // ユーザーのEthereumプロバイダーを取得します。
      const provider = new ethers.providers.Web3Provider(window.ethereum);

      // ユーザーにウォレット接続を要求します。
      await provider.send("eth_requestAccounts", []);

      // サインインしているアカウントを使用してサインャーを取得します。
      const signer = provider.getSigner();

      // Ethers.jsを使用してコントラクトに接続します。
      const factoryContract = new ethers.Contract(factoryAddress, factoryAbi, signer);

      // コントラクトの関数を呼び出して新しいNFTコントラクトを作成します。
      const transaction = await factoryContract.createNFTContract(name, symbol);

      // トランザクションがマイニングされるまで待ちます。
      const tx = await transaction.wait();

      // イベントを正しく取得するための修正されたコード。
      const newContractEvent = tx.events.find((e) => e.event === 'NFTContractCreated');
      const newContractAddress = newContractEvent ? newContractEvent.args.contractAddress : null;

      if (newContractAddress) {
        // ステートに新しいコントラクトのアドレスをセットします。
        setContractAddress(newContractAddress);
      } else {
        console.error('No NFTContractCreated event found');
      }
    } catch (error) {
      console.error('Error creating new NFT contract:', error);
    }
  };

  return (
    <div className={styles.container}>
      <input
        className={styles.input}
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="NFT Collection Name"
      />
      <input
        className={styles.input}
        value={symbol}
        onChange={(e) => setSymbol(e.target.value)}
        placeholder="NFT Symbol"
      />
      <button
        className={styles.button}
        onClick={createNFTContract}
      >
        Create NFT Contract
      </button>
      {contractAddress && (
        <p className={styles.address}>New Contract Address: {contractAddress}</p>
      )}
    </div>
  );
};

export default SvgFactory;


