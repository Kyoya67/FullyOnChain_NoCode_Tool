import React, { useState } from 'react';
import { ethers } from 'ethers';
import svgAbi from './abi/mint.json'; // SVG NFTコントラクトのABIをここに置きます。
import styles from './css/SvgMint.module.css'

// SVG NFTコントラクトのABIを設定します。
const SvgMint = () => {
  const [contractAddress, setContractAddress] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [workData, setWorkData] = useState('');

  const mintNFT = async () => {
    try {
      if (!contractAddress) throw new Error("Contract address is required");

      // ユーザーのEthereumプロバイダーを取得します。
      const provider = new ethers.providers.Web3Provider(window.ethereum);

      // ユーザーにウォレット接続を要求します。
      await provider.send("eth_requestAccounts", []);

      // サインインしているアカウントを使用してサインャーを取得します。
      const signer = provider.getSigner();

      // Ethers.jsを使用してコントラクトに接続します。
      const svgContract = new ethers.Contract(contractAddress, svgAbi, signer);

      // コントラクトのnftMint関数を呼び出します。
      const transaction = await svgContract.nftMint(title, description, workData);

      // トランザクションがマイニングされるまで待ちます。
      await transaction.wait();

      console.log(`NFT minted: ${transaction.hash}`);
    } catch (error) {
      console.error('Error minting NFT:', error);
    }
  };

  return (
    <div className={styles.container}>
      <input
        className={styles.input}
        value={contractAddress}
        onChange={(e) => setContractAddress(e.target.value)}
        placeholder="Contract Address"
      />
      <input
        className={styles.input}
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="NFT Title"
      />
      <textarea
        className={`${styles.input} ${styles.textarea}`}
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="NFT Description"
      />
      <input
        className={styles.input}
        value={workData}
        onChange={(e) => setWorkData(e.target.value)}
        placeholder="Base64 Encoded SVG"
      />
      <button
        className={styles.button}
        onClick={mintNFT}
      >
        Mint NFT
      </button>
    </div>
  );
};

export default SvgMint;
